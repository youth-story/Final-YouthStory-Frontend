import React from "react";
import styles from "./Thumbnail.module.css";

export default function Thumbnail({ story }) {

    return (
        <div className={styles.container}>
           <img className={styles.thumbnail} src={story.thumbnail} alt="Story's Thumbnail" />
           <p className={styles.title}>{story.title}</p>
        </div>
    );

}