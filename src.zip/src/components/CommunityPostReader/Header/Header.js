import React from "react";
import styles from "./Header.module.css";

export default function Header({coverPic, title, date, category}) {

    return (
        <div className={styles.container}>
           <img className={styles.coverPic} src={coverPic} alt="Cover Picture" />
           <p className={styles.title}>{title}</p>
           <div className={styles.meta}>
                <p className={styles.date}>{date}</p>
                <p className={styles.category}>Category: {category}</p>
           </div>
        </div>
    );

}