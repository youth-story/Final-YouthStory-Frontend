import React from "react";
import styles from "./Content.module.css";

export default function Content({
  coverPic,
  author,
  profilePic,
  content,
  achievements,
}) {
  return (
    <div className={styles.container}>
      <div className={styles.generalInfo}>
        <img className={styles.coverPic} src={coverPic} alt="Cover Picture" />
        {achievements.map((achievement, index) => (
          <p className={styles.achievement} key={index}>
            {achievement}
          </p>
        ))}
      </div>
      <div className={styles.content}>
        <p>{content}</p>
        <div className={styles.authorInfo}>
          <img
            className={styles.profilePic}
            src={profilePic}
            alt="Author's Profile Pic"
          />
          <p className={styles.author}>{author}</p>
        </div>
      </div>
    </div>
  );
}
