import React, { useState } from "react";
import styles from "./ForgotPasswordForm.module.css";
import InputField from "../../../utils/Input/InputField";

export default function ForgotPasswordForm() {

  const [showOTP, setShowOTP] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [data, setData] = useState({
    email: "",
    otp: "",
    newPassword: "",
  });
  const [error, setError] = useState({
    msg: "",
    has: false,
  });

  const updateData = (newData) => {
    setData((prevData) => ({
      ...prevData,
      ...newData,
    }));
  };

  const submitForm = (e) => {
    e.preventDefault();
    const { email, otp } = data;
    const errorObj = { msg: "", has: false };

    if (!email.trim()) {
      errorObj.msg = "All fields are required.";
      errorObj.has = true;
    } 

    setError(errorObj);

    if (!errorObj.has) {
      if (showOTP) {
        // Handle OTP verification
        verifyOTP(data.otp);
      } else {
        // Perform the ForgotPassword action here
        setShowOTP(true);
      }
    }
  };

  const verifyOTP = (otp) => {
    setShowPassword(true);
    setShowOTP(false);
  };

  const openSignupForm = () => {
    localStorage.removeItem("openFP");
    localStorage.setItem("modalOpened", "true");
  };

  return (
    <div className={styles.container}>
      <h2 style={{ marginBottom: 0, paddingBottom: 0 }}>Forgot Password?</h2>
      <p style={{ fontSize: "0.8rem" }}>{!showOTP ? (!showPassword ? 'Please enter your email' : '' ) : `An OTP has been sent to ${data.email}`}</p>
      <p style={{ width: '20vw', color: 'red', wordWrap: 'break-word' }}>{error.msg}</p>
      <form onSubmit={submitForm}>
        {!showOTP && !showPassword ? (
          <>
            <InputField
              placeholder={"Email"}
              data={data.email}
              updateData={(value) => updateData({ email: value })}
            />
          </>
        ) : null}
        {showOTP && (
          <InputField
            placeholder={"OTP"}
            data={data.otp}
            updateData={(value) => updateData({ otp: value })}
          />
        )}
        {showPassword && (<>
          <p>Enter new Password</p>
           <InputField
           placeholder={"Password"}
           data={data.password}
           updateData={(value) => updateData({ password: value })}
         />
         <p>Confirm new Password</p>
         <InputField
           placeholder={"Password"}
           data={data.password}
           updateData={(value) => updateData({ password: value })}
         />
         </>
        )}
        <br />
        {!showOTP ? (
          <button type="submit" className={styles.submitBtn}>
            Submit
          </button>
        ) : ( !showPassword ? (
          <button type="submit" className={styles.submitBtn}>
            Verify
          </button> ) : (
            <button type="submit" className={styles.submitBtn}>
            Set Password
          </button>
          )
        )}
      </form>
      <br />
      <a
        style={{ alignSelf: "center", color: "white", textDecoration: "none" }}
        onClick={openSignupForm}
      >
        Don't have an account? Signup
      </a>
    </div>
  );
}
