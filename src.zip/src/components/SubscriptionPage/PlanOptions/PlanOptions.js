import React, { useState } from "react";
import styles from "./PlanOptions.module.css";

export default function PlanOptions({ plan }) {
  const [readMore, setReadMore] = useState(false);

  const toggleReadOption = () => setReadMore((prevReadMore) => !prevReadMore);

  return (
    <div className={styles.container} style={{height: readMore ? 'fit-content' : 'fit-content'}}>
      <p className={styles.planName}>{plan.planName}</p>
      <p className={styles.cost}>{plan.cost}</p>
      <p className={styles.duration}>{plan.duration} period</p>
      {plan.premiumSupport && (
        <p className={styles.premiumSupport}>Premium Support</p>
      )}
      <ul className={styles.perks}>
        {plan.keyPerks.map((perk, index) => (
          <li className={styles.perk} key={index}>
            {perk}
          </li>
        ))}
      </ul>
      <p className={styles.readMore} onClick={toggleReadOption}>
        {readMore ? "READ LESS" : "READ MORE"}
      </p>
      {
        readMore && (
            <ul className={styles.morePerks}>
        {plan.morePerks.map((perk, index) => (
          <li className={styles.perk} key={index}>
            {perk}
          </li>
        ))}
      </ul>
        )
      }
      <br />
      <button className={styles.buttonTitle}>{plan.buttonTitle}</button>
    </div>
  );
}
