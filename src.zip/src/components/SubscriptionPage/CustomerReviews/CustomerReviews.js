import React from "react";
import styles from "./CustomerReviews.module.css";
import ReviewCards from "./ReviewCards/ReviewCards";

export default function CustomerReviews() {
  return (
    <div className={styles.container}>
     <p className={styles.heading}>Join 1000+ Happy Premium Users</p>
     <div className={styles.reviewContainer}>
        <ReviewCards reviewer={"John Doe"} profession="Brand Manager" pic="https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI" review="Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon" />
        <ReviewCards reviewer={"John Doe"} profession="Brand Manager" pic="https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI" review="Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon" />
        <ReviewCards reviewer={"John Doe"} profession="Brand Manager" pic="https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI" review="Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon" />
     </div>
    </div>
  );
}
