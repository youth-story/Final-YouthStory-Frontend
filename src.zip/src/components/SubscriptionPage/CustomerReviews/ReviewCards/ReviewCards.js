import React from "react";
import styles from "./ReviewCards.module.css";

export default function ReviewCards({ reviewer, pic, review, profession }) {
  return (
    <div className={styles.container}>
        <p className={styles.review}>{review}</p>
        <div className={styles.about}>
        <img className={styles.pic} src={pic} alt="Reviewer Pic" />
        <div className={styles.details}>
            <p className={styles.reviewer}>{reviewer}</p>
            <p className={styles.profession}>{profession}</p>
        </div>
        </div>
    </div>
  );
}
