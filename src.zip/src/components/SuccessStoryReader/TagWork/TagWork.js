import React from "react";
import styles from "./TagWork.module.css";

export default function TagWork({ TagWork, info }) {

    return (
        <div className={styles.container}>
            <p className={styles.tagWork}>{TagWork}</p>
            <div className={styles.info}>
                <div className={styles.field}>
                    <p className={styles.key}>Background</p>
                    <p className={styles.value}>{info[0].Background}</p>
                </div>
                <div className={styles.field}>
                    <p className={styles.key}>Platform</p>
                    <p className={styles.value}>{info[1].Platform}</p>
                </div>
                <div className={styles.field}>
                    <p className={styles.key}>Work Type</p>
                    <p className={styles.value}>{info[2].WorkType}</p>
                </div>
                <div className={styles.field}>
                    <p className={styles.key}>City</p>
                    <p className={styles.value}>{info[3].City}</p>
                </div>
            </div>
        </div>
    );

}