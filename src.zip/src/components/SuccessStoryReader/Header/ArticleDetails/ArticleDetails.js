import React from "react";
import styles from "./ArticleDetails.module.css";

export default function ArticleDetails({writer, date}) {

    return (
        <div className={styles.container}>
            <div className={styles.field1}>
                <p className={styles.key}>DESIGNER INTERVIEW</p>
                <p className={styles.value}>{date}</p>
            </div>
            <div className={styles.field2}>
                <p className={styles.key}>WRITER</p>
                <p className={styles.value}>{writer}</p>
            </div>
        </div>
    );
    
}