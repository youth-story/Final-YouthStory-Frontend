import React from "react";
import styles from "./Header.module.css";
import ArticleDetails from "./ArticleDetails/ArticleDetails";

export default function Header({ person, writer, date, image, work }) {

    return (
        <div className={styles.container}>
            <p className={styles.person}>{person}</p>
            <ArticleDetails writer={writer} date={date} />
            <p className={styles.work}>{work}</p>
            <img className={styles.img} src={image} alt="Interviewee's Image" />
        </div>
    );

}