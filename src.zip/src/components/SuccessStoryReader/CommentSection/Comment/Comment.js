import React from "react";
import styles from "./Comment.module.css";

export default function Comment({ comment }) {
  return (
    <div className={styles.container}>
      <div className={styles.info}>
        <img className={styles.dp} src={comment.profilePic} alt="Profile Pic" />
        <div className={styles.contact}>
          <p className={styles.username}>@{comment.username}</p>
          <p className={styles.date}>{comment.date}</p>
        </div>
      </div>
      <p className={styles.comment}>{comment.comment}</p>
    </div>
  );
}
