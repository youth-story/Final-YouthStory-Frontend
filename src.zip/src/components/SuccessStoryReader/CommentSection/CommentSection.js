import React, { useState } from "react";
import styles from "./CommentSection.module.css";
import Comment from "./Comment/Comment";
import comments from "../../../constantsAPI/SuccessStoryReader/comment"; // Replace with API

export default function CommentSection() {
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");

  const updateComment = (e) => {
    setComment(e.target.value);
  };

  const addComment = () => {
    if (comment.trim() == "") {
      setError("Comment is empty");
      return;
    } else if ( comment.trim() !== "" && comment.length > 200) {
      setError("Comment exceeds 200 characters");
      return;
    }

    const dateObject = new Date();

    const day = dateObject.getDate();
    const monthIndex = dateObject.getMonth();
    const year = dateObject.getFullYear();

    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const monthName = monthNames[monthIndex];
    const newComment = {
      profilePic:
        "https://media.licdn.com/dms/image/C4E03AQG4d9eWRCBqBQ/profile-displayphoto-shrink_800_800/0/1598353626550?e=1705536000&v=beta&t=oaAEkuXJBpHsfdm47x2gicDsNNFZZSa_CLk8hjgfY94",
      username: "olaHero",
      date: `${day} ${monthName}, ${year}`,
      comment: comment,
    };
    comments.push(newComment);
    setComment("");
  setError("");
  };

  return (
    <div className={styles.container}>
      <p className={styles.heading}>Add a Comment</p>
      <div className={styles.typeComment}>
        <p className={styles.error}>{error}</p>
        <textarea
          className={styles.commentText}
          value={comment}
          onChange={updateComment}
          placeholder="Type anything..."
          rows={4}
          cols={50}
        />
        <button className={styles.addCommentBtn} onClick={addComment}>
          Send Comment
        </button>
      </div>
      <div className={styles.comments}>
        {comments.map((comment, index) => (
          <Comment comment={comment} key={index} />
        ))}
      </div>
    </div>
  );
}
