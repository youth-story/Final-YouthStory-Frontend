import React, { useState, useEffect } from "react";
import styles from "./ShowThumbnails.module.css";
import Thumbnail from "../../SuccessStory/Thumbnail/Thumbnail";
import top2Stories from "../../../constantsAPI/Home/top2Stories"; // Replace with API

export default function ShowThumbnails() {
  const [articles, setArticles] = useState();

  useEffect(() => {
    setArticles(top2Stories);
  }, []);

  return (
    <div className={styles.container}>
      <p className={styles.title}>
        Latest: {articles && articles.month} {articles && articles.week} Week Stories
      </p>
      <div className={styles.stories}>
        {articles &&
          articles.items.map((article, index) => (
            <div className={styles.thumbnailWrapper} key={index}>
              <Thumbnail story={article} />
            </div>
          ))}
      </div>
    </div>
  );
}
