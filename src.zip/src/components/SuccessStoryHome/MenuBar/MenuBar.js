import React, { useState, useEffect } from "react";
import styles from "./MenuBar.module.css";
import ShowThumbnails from "../ShowThumbnails/ShowThumbnails";

export default function MenuBar() {
  const getCurrentMonth = () => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    return currentMonth;
  };

  const getCurrentWeek = () => {
    const currentDate = new Date();
    const currentWeek = Math.ceil(currentDate.getDate() / 7);
    return currentWeek;
  };

  const [selectedOptions, setSelectedOptions] = useState({
    month: getCurrentMonth(),
    week: getCurrentWeek() - 1,
  });

  const [isDropdownOpen, setDropdownOpen] = useState(false);

  const [selectedWeek, setSelectedWeek] = useState(null);

  const handleSelectWeek = (weekNumber) => {
    setSelectedWeek(weekNumber);
  };

  useEffect(() => {
    setSelectedOptions({
      month: getCurrentMonth(),
      week: getCurrentWeek() - 1,
    });
  }, []);

  const handleSelectChange = (value) => {
    setSelectedOptions((prev) => ({ ...prev, ...value }));
  };

  const monthOptions = [
    { value: 1, label: "January" },
    { value: 2, label: "February" },
    { value: 3, label: "March" },
    { value: 4, label: "April" },
    { value: 5, label: "May" },
    { value: 6, label: "June" },
    { value: 7, label: "July" },
    { value: 8, label: "August" },
    { value: 9, label: "September" },
    { value: 10, label: "October" },
    { value: 11, label: "November" },
    { value: 12, label: "December" },
  ];

  return (
    <div className={styles.container}>
      <div className={styles.menu}>
        <select
          id="selectOption"
          value={selectedOptions.month}
          onChange={(e) =>
            handleSelectChange({ ...selectedOptions, month: e.target.value })
          }
          onClick={() => setDropdownOpen(true)}
          onBlur={() => setDropdownOpen(false)}
          className={`${styles.monthMenu} ${
            isDropdownOpen ? styles.clicked : ""
          }`}
        >
          {monthOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        {/* <div className={styles.weekOptions}> */}
        {[1, 2, 3, 4].map((weekNumber) => (
        <p
          key={weekNumber}
          className={`${styles.week} ${selectedWeek === weekNumber ? styles.selectedWeek : ''}`}
          onClick={() => handleSelectWeek(weekNumber)}
        >
          Week {String(weekNumber).padStart(2, '0')}
        </p>
      ))}
        {/* </div> */}
      </div>
      <ShowThumbnails
        month={selectedOptions.month}
        week={selectedOptions.week}
      />
    </div>
  );
}
