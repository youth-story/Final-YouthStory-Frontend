import React, { useState } from "react";
import styles from "./SignupForm.module.css";
import InputField from "../../../utils/Input/InputField";
import { header } from "../../../utils/headers";
import axios from 'axios';

export default function SignupForm() {
  const [showOTP, setShowOTP] = useState(false);
  const [data, setData] = useState({
    username: "",
    email: "",
    password: "",
    name: "",
    otp: "",
    checked: false,
  });
  const [error, setError] = useState({
    msg: "",
    has: false,
  });

  const downloadPdf = (pdfPath, fileName) => {
    const link = document.createElement("a");
    link.href = pdfPath;
    link.download = fileName;
    link.click();
  };

  const updateData = (newData) => {
    setData((prevData) => ({
      ...prevData,
      ...newData,
    }));
  };

  const submitForm = async (e) => {
    e.preventDefault(); // Prevent the default form submission behavior
    // Your existing validation logic here
    const { username, email, password, name, otp, checked } = data;
    const errorObj = { msg: "", has: false };

    if (!username.trim() || !email.trim() || !password.trim() || !name.trim() || !checked) {
      errorObj.msg = "All fields are required.";
      errorObj.has = true;
    } else if (username.trim().length < 2 || username.trim().length > 50) {
      errorObj.msg = "Username should be between 2 and 50 characters.";
      errorObj.has = true;
    } else if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
      errorObj.msg = "Invalid email address.";
      errorObj.has = true;
    } else if (
      name.trim().split(" ").length !== 2 ||
      name.replace(/\s/g, "").length < 4 ||
      name.replace(/\s/g, "").length > 50
    ) {
      errorObj.msg = "Name should have two words and be between 4 and 50 characters.";
      errorObj.has = true;
    } else if (
      !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password) ||
      /\s/.test(password)
    ) {
      errorObj.msg =
        "Password should have at least 8 characters with 1 lowercase, 1 uppercase, 1 special character, 1 number, and no spaces.";
      errorObj.has = true;
    }

    setError(errorObj);

    if (!errorObj.has) {

      if (showOTP) {
        // Handle OTP verification
        verifyOTP(data.otp);
      } else {
        // Perform the signup action here
        try {
          const response = await axios.post(`${header}/api/auth/sign-up`, {
            "email": data.email,
            "name": data.name,
            "username": data.username,
            "password": data.password
          });

        }
        catch (error)
        {
          setError({msg: error.response.data.error, has:true});
          return;
        }
        setShowOTP(true);
      }
    }
  };

  const verifyOTP = async (otp) => {
    // Handle OTP verification
    
    try {
      const response = await axios.post(`${header}/api/auth/verify-otp`, {
        "email": data.email,
        "otp": data.otp,
        "type": "signUp"
      });

    }
    catch (error)
    {
      console.log(error);
      setError({msg: error.response.data.error, has:true});
      return;
    }

  };

  const openLoginForm = () => {
    localStorage.removeItem("modalOpened");
    localStorage.setItem("openLogin", "true");
  };

  return (
    <div className={styles.container}>
      <h2 style={{ marginBottom: 0, paddingBottom: 0 }}>Signup</h2>
      <p style={{ fontSize: "0.8rem" }}>{!showOTP ? 'Just some details to get you in.' : `An OTP has been sent to ${data.email}`}</p>
      <p className={styles.error}>{error.msg}</p>
      <form onSubmit={submitForm}>
        {!showOTP ? (
          <>
            <InputField
              placeholder={"Name"}
              data={data.name}
              updateData={(value) => updateData({ name: value })}
            />
            <InputField
              placeholder={"Username"}
              data={data.username}
              updateData={(value) => updateData({ username: value })}
            />
            <InputField
              placeholder={"Email"}
              data={data.email}
              updateData={(value) => updateData({ email: value })}
            />
            <InputField
              placeholder={"Password"}
              data={data.password}
              updateData={(value) => updateData({ password: value })}
            />
            <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            id="acceptTerms"
            checked={data.checked}
            onChange={(e) => updateData({ checked: !data.checked })}
          />
          <label htmlFor="acceptTerms" style={{ color: "white" }}>
            I accept{" "}
            <a
              style={{ color: "red", textDecoration: "none" }}
              href="#"
              onClick={() =>
                downloadPdf(
                  "../../pdf/terms.pdf",
                  "Terms & Conditions - YouthStory.in"
                )
              }
            >
              Terms & Conditions
            </a>{" "}
            and{" "}
            <a
              style={{ color: "red", textDecoration: "none" }}
              href="#"
              onClick={() =>
                downloadPdf(
                  "../../pdf/privacy.pdf",
                  "Privacy Policy - YouthStory.in"
                )
              }
            >
              Privacy Policy
            </a>
          </label>
        </div>
          </>
        ) : null}
        {showOTP && (
          <InputField
            placeholder={"OTP"}
            data={data.otp}
            updateData={(value) => updateData({ otp: value })}
          />
        )}
        <br />
        <div className={styles.btnContainer}>
        {!showOTP ? (
          <button type="submit" className={styles.submitBtn}>
            Signup
          </button>
        ) : (
          <button type="submit" className={styles.submitBtn}>
            Verify
          </button>
        )}
        </div>
      </form>
      <br />
      <a
        style={{ alignSelf: "center", color: "white", textDecoration: "none" }}
        onClick={openLoginForm}
      >
        Already registered? Login
      </a>
    </div>
  );
}
