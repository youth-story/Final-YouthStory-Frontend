// TechTrendingPosts.js

import React, { useState, useRef, useEffect } from "react";
import styles from "./TrendingPosts.module.css";
import PostCover from "../PostCover/PostCover";

export default function TrendingPosts({data}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const cardsPerPage = 3; // Adjust this based on the number of cards visible on the screen
  const sliderRef = useRef(null);

  useEffect(() => {
    const sliderWidth = sliderRef.current.offsetWidth;
    const cardsPerPage = Math.floor(sliderWidth / sliderRef.current.children[0].offsetWidth);
    setCurrentIndex(0);
  }, [currentIndex]);

  const handlePrevClick = () => {
    setCurrentIndex((prevIndex) => Math.max(prevIndex - cardsPerPage, 0));
  };

  const handleNextClick = () => {
    const remainingCards = data.length - (currentIndex + cardsPerPage);
    if (remainingCards > 0) {
      setCurrentIndex((prevIndex) => prevIndex + cardsPerPage);
    }
  };

  // Calculate transform value
  const sliderTransformValue = `translateX(-${currentIndex * 100}%)`;

  return (
    <div className={styles.container}>
      <button onClick={handlePrevClick} disabled={currentIndex === 0}>
        Prev
      </button>
      <div className={styles.sliderContainer} ref={sliderRef}>
        <div className={styles.slider} style={{ transform: sliderTransformValue }}>
        {data.map((post, index) => (
            <PostCover key={index} post={post} />
          ))}
        </div>
      </div>
      <button
        onClick={handleNextClick}
        disabled={currentIndex >= data.length - cardsPerPage}
      >
        Next
      </button>
    </div>
  );
}
