import React from "react";
import styles from "./PostCover.module.css";

export default function PostCover({ post }) {
    const maxTitleLines = 3;

    return (
        <div className={styles.container}>
            <img className={styles.image} src={post.image} alt="Post Image" />
            <div className={styles.infoContainer}>
                <p className={`${styles.title} ${styles.clamped}`} style={{ WebkitLineClamp: maxTitleLines }}>
                    {post.title}
                </p>
            </div>
            <div className={styles.about}>
                <img className={styles.profilePic} src={post.profilePic} alt="Profile Pic" />
                <div className={styles.details}>
                    <p className={styles.user}>{post.user}</p>
                    <p className={styles.date}>{post.date}</p>
                </div>
            </div>
        </div>
    );
}
