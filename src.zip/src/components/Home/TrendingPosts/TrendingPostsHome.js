import React from "react";
import styles from "./TrendingPostsHome.module.css";
import postCoverInfo from "../../../constantsAPI/CommunityPostHome/CommunityPostCover"; // Replace with API
import TrendingPosts from "../../CommunityPostHome/TrendingPosts/TrendingPosts";

export default function TrendingPostsHome() {
  return (
    <div className={styles.container}>
      <div className={styles.container}>
        <div className={styles.trendingSectionHeader}>
          <p className={styles.trendingID}>Community Post</p>
          <p className={styles.techTrending}>What's Trending!</p>
          <TrendingPosts data={postCoverInfo} />
        </div>
      </div>
    </div>
  );
}
