import React from "react";
import styles from "./MembershipBanner.module.css";
import CardCarousel from "./CardCarousel/CardCarousel";

export default function MembershipBanner() {

    return (
        <div className={styles.container}>
            <div className={styles.card}>
                <p className={styles.title}>D2D PREMIUM MEMBERSHIP</p>
                <CardCarousel images={["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQmke3yrRKuUQ0o_Zb7VYgawBPcOctd4arFw&usqp=CAU"]} />
                <button className={styles.grabBtn}>GRAB TODAY</button>
            </div>
        </div>
    );

}