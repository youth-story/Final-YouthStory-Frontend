import React from "react";
import styles from "./CurrentMonthStories.module.css";
import Thumbnail from "../../SuccessStory/Thumbnail/Thumbnail";

export default function CurrentMonthStories({ top2Stories }) {
  return (
    <div className={styles.container}>
        <div className={styles.titleShowAllBtn}>
      <p className={styles.title}>
        {top2Stories.month} - {top2Stories.week} Week Stories
      </p>
      <button className={styles.showAllBtn}>Show All {'>'}</button>
      </div>
      <div className={styles.stories}>
        {top2Stories.items.map((story, index) => (
          <Thumbnail story={story} key={index} />
        ))}
      </div>
    </div>
  );
}
