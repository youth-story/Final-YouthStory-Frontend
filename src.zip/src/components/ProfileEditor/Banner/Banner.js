import React, { useState } from "react";
import styles from "./Banner.module.css";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";

export default function Banner({ banner, onChange }) {
  const [image, setImage] = useState(null);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    const imageUrl = URL.createObjectURL(file);
    setImage(imageUrl);
    onChange(imageUrl);
  };

  const logoImageStyle = {
    fontSize: "150px", 
    marginBottom: "10px",
  };

  const imageContainerStyle = {
    width: "95%",
    height: "400px",
    display: "flex",
    flexDirection: "column", 
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    backgroundColor: "#F7F7F7",
    border: "2px dashed #ccc",
    borderRadius: '12px',
    backgroundSize: "4px 8px",
  };

  const uploadedImageStyle = {
    maxWidth: "93%",
    maxHeight: "100%",
    objectFit: "contain",
    position: "absolute",
    top: "0",
    left: "0",
    width: "93%",
    height: "100%"
  };

  const dropImageLabelStyle = {
    cursor: "pointer",
    textAlign: "center",
  };

  return (
    <div className={styles.imgUpdContainer} style={{ display: "flex", flexDirection: "column", width: "100%", justifySelf: "center", alignSelf: "center", alignItems: "center", justifyContent: "center" }}>
      <label htmlFor="image-upload" style={{ textAlign: "left", alignSelf: "flex-start", fontWeight: "600", marginBottom: "7px", position: "relative", left: "20px" }}>
        Add Banner
      </label>
      <div className={styles.imgContainer} style={imageContainerStyle}>
        <DriveFolderUploadOutlinedIcon style={logoImageStyle} />
        <input
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          id="image-upload"
          style={{ display: "none" }}
        />
        <label
          htmlFor="image-upload"
          style={dropImageLabelStyle}
        >
          Drop Image or Click Here
        </label>
        {image && <img style={uploadedImageStyle} src={image} alt="Uploaded" />}
      </div>
    </div>
  );
}
