import React, { useState } from "react";
import styles from "./Image.module.css";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";

export default function Image({ imageData, onChange }) {
  const [imageD, setImageD] = useState(null);

  const handleImageDUpload = (event) => {
    const file = event.target.files[0];
    const imageUrl = URL.createObjectURL(file);
    setImageD(imageUrl);
    onChange(imageUrl);
  };

  const logoImageDStyle = {
    fontSize: "150px",
    marginBottom: "10px",
  };

  const imageDContainerStyle = {
    width: "100%",
    height: "400px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    backgroundColor: "#F7F7F7",
    border: "2px dashed #ccc",
    borderRadius: '12px',
    backgroundSize: "4px 8px",
  };

  const uploadedImageDStyle = {
    maxWidth: "100%",
    maxHeight: "100%",
    objectFit: "contain",
    position: "absolute",
    top: "0",
    left: "0",
    width: "100%",
    height: "100%"
  };

  const dropImageDLabelStyle = {
    cursor: "pointer",
    textAlign: "center",
  };

  return (
    <div className={styles.imgUpdContainer} style={{ display: "flex", flexDirection: "column", width: "30%", justifySelf: "center", alignSelf: "center", alignItems: "center", justifyContent: "center" }}>
      <label htmlFor="image-upload" style={{ textAlign: "left", alignSelf: "flex-start", fontWeight: "600", marginBottom: "7px", position: "relative", left: "20px" }}>
        Add Image
      </label>
      <div
        className={styles.imgContainer}
        style={{
          ...imageDContainerStyle,
          width: "100%",
        }}
      >
        <DriveFolderUploadOutlinedIcon style={logoImageDStyle} />
        <input
          type="file"
          accept="image/*"
          onChange={handleImageDUpload}
          id="image-upload-dp"
          style={{ display: "none" }}
        />
        <label
          htmlFor="image-upload-dp"
          style={dropImageDLabelStyle}
        >
          Drop Image or Click Here
        </label>
        {imageD && <img style={uploadedImageDStyle} src={imageD} alt="Uploaded" />}
      </div>
    </div>
  );
}
