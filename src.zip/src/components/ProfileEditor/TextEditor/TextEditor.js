import React from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import styles from "./TextEditor.module.css";

const modules = {
  toolbar: [
    [{ header: "1" }, { header: "2" }, { font: [] }],
    [{ list: "ordered" }, { list: "bullet" }],
    ["bold", "italic", "underline"],
    ["link", "image"],
    [{ align: [] }],
  ],
};

const formats = [
  "header",
  "font",
  "list",
  "bold",
  "italic",
  "underline",
  "link",
  "align",
];

const inputStyle = {
  borderRadius: "10px",
  backgroundColor: "#F7F7F7", // Set the background color to grey for input fields
};

const editorStyle = {
  height: "400px", // Set your desired fixed height
  width: "100%", // Set your desired width
  justifySelf: "center",
  alignSelf: "center",
  margin: "20px",
  overflowY: "auto", // Add a scrollbar when content exceeds the fixed height
};

export default function TextEditor({ bio, onChange }) {
  return (
    <div
      className={styles.editorContainer}
      style={{ ...editorStyle, width: "60%" }} // Default width
    >
      <style>
        {`
          @media (max-width: 768px) {
            .${styles.editorContainer} {
              width: 100%;
            }
          }
        `}
      </style>
      <label htmlFor="text-area" style={{ fontWeight: "bold" }}>
        Write about yourself
      </label>
      <ReactQuill
        id="text-area"
        value={bio}
        onChange={(value) => onChange({ bio: value })}
        modules={modules}
        formats={formats}
        placeholder="Type..."
        style={inputStyle}
      />
    </div>
  );
}
