import React, { useState } from "react";
import styles from "./InfoFields.module.css";
import ProfileInput from "../../../utils/ProfileInput/ProfileInput";

export default function InfoFields(props) {

  return (
    <div className={styles.container}>
        <ProfileInput placeholder="First Name" value={props.data.firstName} onChange={(e) => props.updateData({ firstName: e.target.value })} type="text" />
        <ProfileInput placeholder="Last Name" value={props.data.lastName} onChange={(e) => props.updateData({ lastName: e.target.value })} type="text" />
        <ProfileInput placeholder="User Name" value={props.data.userName} onChange={(e) => props.updateData({ userName: e.target.value })} type="text" />
        <ProfileInput placeholder="Old Password" value={props.data.oldPassword} onChange={(e) => props.updateData({ oldPassword: e.target.value })} type="password" />
        <ProfileInput placeholder="New Password" value={props.data.newPassword} onChange={(e) => props.updateData({ newPassword: e.target.value })} type="password" />
        <ProfileInput placeholder="Email" value={props.data.email} onChange={(e) => props.updateData({ email: e.target.value })} type="email" />
    </div>
  );
}
