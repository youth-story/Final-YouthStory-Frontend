import React, { useState } from "react";
import styles from "./DetailsCard.module.css";
import verfied from "./verified.png";

export default function DetailsCard({ details }) {

    const [follow, setFollow] = useState(details.follow);

    const toggleFollow = () => {
        setFollow((prevFollow) => !prevFollow);
    }    

  return (
    <div className={styles.container}>
      <img
        className={styles.image}
        src={details.image}
        alt="User's Profile Image"
      />
      <div className={styles.info}>
        <div className={styles.verified}>
          <p className={styles.name}>{details.name}</p>
          {details.verified && (
            <img
              src={verfied}
              className={styles.verifiedImg}
              alt="Verified Profile Icon"
            />
          )}
        </div>
        <p className={styles.username}>@{details.username}</p>
        <button className={styles.followBtn} onClick={toggleFollow}> 
          {follow ? "Unfollow" : "Follow"}
        </button>
      </div>
    </div>
  );
}
