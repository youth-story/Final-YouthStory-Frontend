import React from "react";
import styles from "./Header.module.css";
import DetailsCard from "./DetailsCard/DetailsCard";

export default function Header({ details }) {

  function formatNumber(num) {
    if (num < 1000) {
      return num.toString();
    } else if (num < 1000000) {
      return (num / 1000).toFixed(1) + 'K';
    } else {
      return (num / 1000000).toFixed(1) + 'M';
    }
  }

  return (
    <div className={styles.container}>
      <img
        src={details.banner}
        className={styles.banner}
        alt="User's Banner Image"
      />
      <div className={styles.info}>
        <DetailsCard details={details} />
        <div className={styles.postsFollowersCount}>
            <p className={styles.postsCount}>Posts: {formatNumber(details.posts)}</p>
            <p className={styles.followersCount}>Followers: {formatNumber(details.followers)}</p>
        </div>
      </div>
    </div>
  );
}
