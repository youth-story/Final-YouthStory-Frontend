import React, { useState } from "react";
import Modal from "react-modal";
import styles from "./PostModal.module.css";
import Checklist from "./Checklist";
import ImageUpload from "./ImageUpload";
import TextEditor from "./TextEditor";
import ArticleTitle from "./ArticleTitle";
import closeIcon from "./closeIcon.png";

Modal.setAppElement("#root"); // Set the root element for accessibility

const PostModal = ({ isOpen, closeModal }) => {
  const [options, setOptions] = useState([]);

  // Handle publishing
  const handlePublish = () => {
    // Implement publishing logic here
    alert("Published");
  };

  return (
    <Modal
      isOpen={isOpen}
      closeModal={closeModal}
      contentLabel="Article Editor Modal"
      className={styles.modalContent}
      overlayClassName={styles.modalOverlay}
    >
      <div className={styles.successStoryEditor}>
        <h2 className={styles.title}>Article Editor</h2>
        <img onClick={closeModal} className={styles.closeIcon} src={closeIcon} alt="Close Article Editor Icon" />
        <div className={styles.titleOptions}>
          <ArticleTitle />
          <Checklist />
        </div>
        <div className={styles.articleImage}>
          <TextEditor />
          <ImageUpload />
        </div>
        <button
          className={styles.publishButton}
          onClick={handlePublish}
          style={{
            backgroundColor: "#B81A1A",
            color: "white",
            fontWeight: "bold",
            width: "100px",
            cursor: "pointer",
            padding: "10px",
            borderRadius: "15px",
            alignSelf: "flex-end",
            border: "none",
          }}
        >
          Send Post
        </button>
      </div>
    </Modal>
  );
};

export default PostModal;
