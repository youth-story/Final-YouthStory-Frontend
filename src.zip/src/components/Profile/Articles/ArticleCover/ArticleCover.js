import React from "react";
import styles from "./ArticleCover.module.css";
import TruncateText from "../../../../utils/TruncateString";

export default function ArticleCover({ article }) {
  return (
    <div className={styles.container}>
        <p className={styles.date}>{article.date}</p>
        <div className={styles.info}>
            <p className={styles.title}>{TruncateText(9, article.title)}</p>
            <img className={styles.image} src={article.image} alt="Article Image" />
        </div>
    </div>
  );
}
