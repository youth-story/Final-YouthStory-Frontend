import React from "react";
import styles from "./Articles.module.css";
import ArticleCover from "./ArticleCover/ArticleCover";

export default function Articles({ articles }) {
  return (
    <div className={styles.container}>
      <p className={styles.title}>ARTICLES:</p>
      <br />
      <div className={styles.articleCovers}>
        {articles.map((article, index) => (
          <ArticleCover article={article} key={index} />
        ))}
      </div>
    </div>
  );
}
