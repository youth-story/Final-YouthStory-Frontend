import React, { useState } from "react";
import styles from "./LoginForm.module.css";
import InputField from "../../../utils/Input/InputField";

export default function LoginForm() {
 
  const [data, setData] = useState({
    username: "",
    password: "",
  });
  const [error, setError] = useState({
    msg: "",
    has: false,
  });

  const updateData = (newData) => {
    setData((prevData) => ({
      ...prevData,
      ...newData,
    }));
  };

  const submitForm = (e) => {
    e.preventDefault(); 

    const { username, password } = data;
    const errorObj = { msg: "", has: false };

    if (!username.trim() || !password.trim()) {
      errorObj.msg = "All fields are required.";
      errorObj.has = true;
    }

    setError(errorObj);

    if (!errorObj.has) {
      alert('Logged In!');
    }
  };

  const openFPForm = () => {
    localStorage.removeItem("openLogin");
    localStorage.addItem("openFP");
  };

  return (
    <div className={styles.container}>
      <h2 style={{ marginBottom: 0, paddingBottom: 0 }}>Login</h2>
      <p style={{ fontSize: "0.8rem" }}>Glad you're back.!</p>
      <p style={{ width: '20vw', color: 'red', wordWrap: 'break-word' }}>{error.msg}</p>
      <form onSubmit={submitForm}>
          <>
            <InputField
              placeholder={"Username"}
              data={data.username}
              updateData={(value) => updateData({ username: value })}
            />
            <InputField
              placeholder={"Password"}
              data={data.password}
              updateData={(value) => updateData({ password: value })}
            />
          </>
        <br />
          <button type="submit" className={styles.submitBtn}>
            Login
          </button>
      </form>
      <br />
      <a
        style={{ alignSelf: "center", color: "white", textDecoration: "none" }}
        onClick={openFPForm}
      >
        Forgot Password?
      </a>
    </div>
  );
}
