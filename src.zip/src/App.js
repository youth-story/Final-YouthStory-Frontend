import React, { useEffect, useState } from "react";
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import Signup from "./pages/Signup/Signup";
import Login from "./pages/Login/Login";
import ForgotPassword from "./pages/ForgotPassword/ForgotPassword";
import SubscriptionPage from "./pages/SubscriptionPage/SubscriptionPage";
import CommunityPostHome from "./pages/CommunityPostHome/CommunityPostHome";
import CommunityPostReader from "./pages/CommunityPostReader/CommunityPostReader";
import Profile from "./pages/Profile/Profile";
import ProfileEditor from "./pages/ProfileEditor/ProfileEditor";
import Home from "./pages/Home/Home";
import SuccessStoryHome from "./pages/SuccessStoryHome/SuccessStoryHome";

import SuccessStoryReader from "./pages/SuccessStoryReader/SuccessStoryReader";
import content from "./constantsAPI/SuccessStoryReader/content";

import AyushSingh from './tempA/AyushSingh';
import BhavayGoyal from './tempA/BhavayGoyal';
import AribaKhan from './tempA/AribaKhan';
import PalakhKhanna from './tempA/PalakhKhanna';
import SimoneSharma from './tempA/SimoneSharma';
import Temp from './tempA/Temp';
import SuccessStories from "./tempA/SuccessStories";
import SuccessStoryEditor from './components/Profile/Articles/PostModal/PostModal';

import communityPostContent from "./constantsAPI/CommunityPostReader/communityPostContent";
import postCoverInfo from "./constantsAPI/CommunityPostHome/CommunityPostCover";
import profileDetails from "./constantsAPI/Profile/profileDetails";

library.add(faEye, faEyeSlash);

function App() {
  const [open, setOpen] = useState(false);
  const [openLogin, setOpenLogin] = useState(false);
  const [openFP, setOpenFP] = useState(false);

  const handleOpen = () => {
    setOpen(true);
    localStorage.setItem("modalOpened", "true");
  };
  const handleOpenLogin = () => {
    setOpenLogin(true);
    localStorage.setItem("openLogin", "true");
  };
  const handleOpenFP = () => {
    setOpenFP(true);
    localStorage.setItem("openFP", "true");
  };

  useEffect(() => {
    if (!localStorage.getItem("modalOpened")) {
      const timeoutId = setTimeout(() => {
        handleOpen();
      }, 10000);

      return () => {
        clearTimeout(timeoutId);
      };
    }
    else if (localStorage.getItem("openLogin")) {
      setOpenLogin(true);
      setOpen(false);
    }
    else {
      handleOpen();
    }
  }, []);

  return (
    <div style={{overflow: "auto"}}>
      {/* <Signup open={open} handleOpen={handleOpen} /> */}
      {/* <Login open={openLogin} handleOpen={handleOpenLogin} /> */}
      {/* <ForgotPassword open={openFP} handleOpen={handleOpenFP} /> */}
      {/* <SuccessStories /> */}
      {/* <Temp><AyushSingh /></Temp> */}
      {/* <Temp><AribaKhan /></Temp>  */}
      {/* <Temp><BhavayGoyal /></Temp> */}
      {/* <Temp><PalakhKhanna /></Temp> */}
      {/* <Temp><SimoneSharma /></Temp> */}
      {/* <SuccessStoryEditor /> */}
      {/* <SubscriptionPage /> */}
      {/* <CommunityPostHome /> */}
      {/* <CommunityPostReader content={communityPostContent} /> */}
      {/* <Profile details={profileDetails} articles={postCoverInfo} /> */}
      {/* <ProfileEditor />  */}
      {/* <Home /> */}
      {/* <SuccessStoryHome /> */}
      {/* <SuccessStoryReader content={content} /> */}
    </div>
  );
}

export default App;
