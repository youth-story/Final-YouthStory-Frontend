import React from 'react';
import Card from 'react-bootstrap/Card';
// import { useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';

function ArticleCard({ article }) {
  // const navigation = useNavigate();

  const handleReadNowClick = () => {
    // navigation(`/success-story/${article.slug}`);
  };

  return (
    <Card style={{ width: 'fit-content', height: 'fit-content', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', border: '1px solid black', borderRadius: '20px', padding: '10px' }}>
      <Card.Img  style={{alignSelf: 'center', justifySelf: 'center', width: "50%", height: "50%", borderRadius: '20px'}} variant="top" src={article.image} />
      <Card.Body>
        <Card.Title><h2>{article.title}</h2></Card.Title>
        <Card.Text>{article.quote}</Card.Text>
        <Button style={{borderRadius: '10px', backgroundColor: 'dodgerblue', color: 'white', padding: '10px', outline: 'none', border: 'none'}} variant="primary" onClick={handleReadNowClick}>Read now</Button>
      </Card.Body>
      <style>
        {`
          @media (max-width: 768px) {
            .card {
              width: fit-content;
              height: 'fit-content';
            }
          }
        `}
      </style>
      <style>
        {`
          @media (max-width: 768px) {
            .card {
              width: fit-content;
              height: 'fit-content';
            }
          }
        `}
      </style>
    </Card>
  );
}

export default ArticleCard;
