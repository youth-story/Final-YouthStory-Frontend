const articles = [
    {
        image: "https://media.licdn.com/dms/image/D4D03AQEC7NXN2_XGug/profile-displayphoto-shrink_800_800/0/1665493308669?e=2147483647&v=beta&t=qJ6TJag6sgMdBu0a8n13kT-8776SRKhrDXvSdwRQH6s",
        title: "How a 13 year old got a high paying job in US!",
        quote: "It’s never a short-cut, it’s always the amount of hard-work you put it in.",
        slug: "ayush-singh",
    },
    {
        image: "https://i.ytimg.com/vi/HgXCa8zvWj0/sddefault.jpg",
        title: "How this 18 year old got 100% scholorship at UBC!",
        quote: "Scholarship applications are unpredictable; you’ll never know if you'll be selected. Keep your hope alive, as there’s no shortcut to success in winning them.",
        slug: "ariba-khan",
    },
    {
        image: "https://media.licdn.com/dms/image/C4D03AQEl6Tb7mWNpag/profile-displayphoto-shrink_800_800/0/1663697282607?e=1704326400&v=beta&t=6jbpJGxmQz6rviqwwG0srkDyYmTs50or_FkG85vyAzo",
        title: "How this 17 year old got Silver Medal at INOI!",
        quote: "JEE isn’t the only way to get into the best colleges in India, if you are dedicated and have the necessary skills then there is no limit to your capabilities.",
        slug: "bhavay-goyal",
    },
    {
        image: "https://media.licdn.com/dms/image/D4D03AQGrQkW6oKS_OA/profile-displayphoto-shrink_800_800/0/1690313315901?e=1704326400&v=beta&t=tHdHRYqwToQ6fkD9EmpE2jp6MZnCKboNdp8KvlBhiPA",
        title: "How this 20 year old became one of Asia's 100 Women Power Leaders!",
        quote: "I haven’t faced any challenges rather I’ve learnt lessons",
        slug: "palakh-khanna",
    },
    {
        image: "https://media.licdn.com/dms/image/D5603AQHcr1dsd1u2FA/profile-displayphoto-shrink_800_800/0/1681121151628?e=1704326400&v=beta&t=ExHGFDV6_ZZNiUyJ_896xc12SSvXvZMmX1NCF_VNnwM",
        title: "How this Harvard fellow is revolutionizing education!",
        quote: "Your belief in your ideas is the first step to turning dreams into reality. Trust in your vision, and others will follow your lead.",
        slug: "simone-sharma",
    }
];

export default articles;