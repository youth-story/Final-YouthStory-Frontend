import React, { useState, useEffect } from 'react';
import styles from './ImageCarousel.module.css'; // Import your CSS module
import c1 from './c1.jpg';
import c2 from './c2.jpg';

const ImageCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [imagesLoaded, setImagesLoaded] = useState(false);

  const data = [
    {
      image: c1,
      caption: 'Introducing D2D',
      description: 'D2D is an all-in-one platform for Youth',
    },
    {
      image: c2,
      caption: 'Youth ka Apna Space',
      description: 'Find success stories, resources, magazines and much more...',
    },
  ];

  useEffect(() => {
    const imagePromises = data.map((item) => {
      return new Promise((resolve) => {
        const img = new Image();
        img.src = item.image;
        img.onload = resolve;
      });
    });

    Promise.all(imagePromises).then(() => setImagesLoaded(true));
  }, []);

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % data.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + data.length) % data.length);
  };

  return (
    <div className={styles.imageCarousel}>
      {imagesLoaded && (
        <>
          <div
            className={styles.carouselContainer}
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {data.map((item, index) => (
              <div key={index} className={styles.carouselItem}>
                <img src={item.image} alt={item.caption} />
                <div className={styles.carouselText}>
                  <h3>{item.caption}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
          <button className={styles.prevButton} onClick={handlePrev}>
            Prev
          </button>
          <button className={styles.nextButton} onClick={handleNext}>
            Next
          </button>
        </>
      )}
    </div>
  );
};

export default ImageCarousel;
