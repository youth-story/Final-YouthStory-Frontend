const comments = [{
    profilePic: "https://media.licdn.com/dms/image/C4E03AQG4d9eWRCBqBQ/profile-displayphoto-shrink_800_800/0/1598353626550?e=1705536000&v=beta&t=oaAEkuXJBpHsfdm47x2gicDsNNFZZSa_CLk8hjgfY94",
    username: "olaHero",
    date: "13 November, 2023",
    comment: "hello"
},
{
    profilePic: "https://media.licdn.com/dms/image/C4E03AQG4d9eWRCBqBQ/profile-displayphoto-shrink_800_800/0/1598353626550?e=1705536000&v=beta&t=oaAEkuXJBpHsfdm47x2gicDsNNFZZSa_CLk8hjgfY94",
    username: "olaHero",
    date: "13 November, 2023",
    comment: "hello"
},
{
    profilePic: "https://media.licdn.com/dms/image/C4E03AQG4d9eWRCBqBQ/profile-displayphoto-shrink_800_800/0/1598353626550?e=1705536000&v=beta&t=oaAEkuXJBpHsfdm47x2gicDsNNFZZSa_CLk8hjgfY94",
    username: "olaHero",
    date: "13 November, 2023",
    comment: "hello"
}
];

export default comments;