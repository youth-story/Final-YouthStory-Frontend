const content = {
    person: "John Doe",
    writer: "Jessy Doe",
    date: "May 10, 2023",
    image: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
    work: "Brand Ambssador at Google India Office of Operations",
    tagLine: "I really enjoyed my journey at Tech Industry. It changed my life and I want others to experience it too",
    tagWork: "Researcher by day, innovator by night",
    info: [{'Background': 'Tech'}, {'Platform': 'NCSC'}, {'WorkType': 'Night Owl'}, {'City': 'Patna'}],
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut gravida felis a odio ultrices tristique. Integer euismod libero in ex venenatis, sit amet luctus libero luctus. Vestibulum ac justo a velit cursus bibendum.

    Sed consequat metus vel justo accumsan, vel efficitur mauris dapibus. Duis euismod libero vitae tortor malesuada, in bibendum ipsum varius. Nulla facilisi. Aenean vel neque in libero fringilla tristique a nec ligula.
    
    Fusce sit amet vestibulum justo. Integer fringilla purus at bibendum tristique. Sed eu arcu vel risus aliquam finibus. Proin eu dui vel ipsum eleifend consequat.
    
    Quisque a risus sit amet urna lacinia ultricies. Phasellus consequat lacus a purus cursus, in malesuada justo fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
    
    In hac habitasse platea dictumst. Praesent nec felis vitae dolor aliquet varius. Suspendisse potenti. Mauris quis enim a velit auctor facilisis. Nunc id semper ligula, eu facilisis libero. Nullam id mi sit amet neque varius tempus.
    
    Duis vel facilisis elit. Aliquam erat volutpat. Integer rhoncus tortor eu ex varius, vel ultricies turpis dapibus. Nunc consectetur, felis eu dignissim iaculis, erat tortor luctus justo, ac bibendum nulla mauris a nulla.
    
    Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vivamus euismod, velit vel pharetra consequat, purus justo iaculis libero, nec euismod sem felis at justo.
    
    `,
};

export default content;