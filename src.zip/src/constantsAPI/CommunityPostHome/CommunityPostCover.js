const postCoverInfo = [
    {
        image: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        title: "Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon",
        user: "John Doe",
        profilePic: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        date: "May 10, 2023",
    },
    {
        image: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        title: "Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon",
        user: "John Doe",
        profilePic: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        date: "May 10, 2023",
    },
    {
        image: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        title: "Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon",
        user: "John Doe",
        profilePic: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        date: "May 10, 2023",
    },
    {
        image: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        title: "Vivid dreams paint the night sky with ethereal colors, whispering secrets to the moon",
        user: "John Doe",
        profilePic: "https://media.licdn.com/dms/image/D4D03AQG3lFT1jg8uYw/profile-displayphoto-shrink_800_800/0/1681595554033?e=1704931200&v=beta&t=jc09TUvyMBKW4wtx0miyzE3wJKB883kw9djhLJO33gI",
        date: "May 10, 2023",
    }
];

export default postCoverInfo;