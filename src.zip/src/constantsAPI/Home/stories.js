const stories = {
    week: "First",
    month: "November",
    items: [
        {
            thumbnail: "https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=600",
            title: "How to bam bam your opponent ;)"
        },
        {
            thumbnail: "https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=600",
            title: "How to bam bam your opponent ;)"
        },
        {
            thumbnail: "https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=600",
            title: "How to bam bam your opponent ;)"
        },
        {
            thumbnail: "https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=600",
            title: "How to bam bam your opponent ;)"
        },
        {
            thumbnail: "https://images.pexels.com/photos/169647/pexels-photo-169647.jpeg?auto=compress&cs=tinysrgb&w=600",
            title: "How to bam bam your opponent ;)"
        },
    ]
};

export default stories;
