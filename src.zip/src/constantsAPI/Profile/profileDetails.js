const profileDetails = {
    banner: "https://images.ctfassets.net/hrltx12pl8hq/3Mz6t2p2yHYqZcIM0ic9E2/3b7037fe8871187415500fb9202608f7/Man-Stock-Photos.jpg",
    image: "https://images.ctfassets.net/hrltx12pl8hq/3Mz6t2p2yHYqZcIM0ic9E2/3b7037fe8871187415500fb9202608f7/Man-Stock-Photos.jpg",
    name: "John Cena",
    username: "MrGangamStyle",
    verified: true,
    followers: 1239,
    role: "user",
    me: false,
    follow: true,
    posts: 8
};

export default profileDetails;