const planOptions = [
    {
        planName: "FREE TRIAL",
        cost: '₹0',
        duration: '7-day',
        keyPerks: ['Up to 1,000 newsletters', 'Own Newsletter email', 'One-click Unsubscribe', 'Newsletters explorer'],
        morePerks: ['Create and manage own labels', 'Share to Facebook, LinkedIn and Twitter(X)', 'Read Later', 'Read History', 'Feed customization', 'Appearance options', 'Different view modes'],
        buttonTitle: 'START FREE TRIAL',
        premiumSupport: false,
    },
    {
        planName: "BRONZE",
        cost: '₹49',
        duration: '3-months',
        keyPerks: ['Up to 1,000 newsletters', 'Own Newsletter email', 'One-click Unsubscribe', 'Newsletters explorer'],
        morePerks: ['Create and manage own labels', 'Share to Facebook, LinkedIn and Twitter(X)', 'Read Later', 'Read History', 'Feed customization', 'Appearance options', 'Different view modes'],
        buttonTitle: 'SUBSCRIBE',
        premiumSupport: false,
    },
    {
        planName: "SILVER",
        cost: '₹199',
        duration: '6-months',
        keyPerks: ['Up to 1,000 newsletters', 'Own Newsletter email', 'One-click Unsubscribe', 'Newsletters explorer'],
        morePerks: ['Create and manage own labels', 'Share to Facebook, LinkedIn and Twitter(X)', 'Read Later', 'Read History', 'Feed customization', 'Appearance options', 'Different view modes'],
        buttonTitle: 'SUBSCRIBE',
        premiumSupport: true,
    },
    {
        planName: "GOLD",
        cost: '₹499',
        duration: '1-year',
        keyPerks: ['Up to 1,000 newsletters', 'Own Newsletter email', 'One-click Unsubscribe', 'Newsletters explorer'],
        morePerks: ['Create and manage own labels', 'Share to Facebook, LinkedIn and Twitter(X)', 'Read Later', 'Read History', 'Feed customization', 'Appearance options', 'Different view modes'],
        buttonTitle: 'SUBSCRIBE',
        premiumSupport: true,
    },
];

export default planOptions;