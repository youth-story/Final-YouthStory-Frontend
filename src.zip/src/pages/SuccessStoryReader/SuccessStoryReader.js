import React from "react";
import styles from "./SuccessStoryReader.module.css";
import Header from "../../components/SuccessStoryReader/Header/Header";
import TagWork from "../../components/SuccessStoryReader/TagWork/TagWork";
import ShowThumbnails from "../../components/SuccessStoryReader/ShowThumbnails/ShowThumbnails";
import CommentSection from "../../components/SuccessStoryReader/CommentSection/CommentSection";

export default function SuccessStoryReader({ content }) {
  return (
    <>
    <Header person={content.person} writer={content.writer} date={content.date} image={content.image} work={content.work} />
    <div className={styles.container}>
      <div className={styles.intro}>
        <div className={styles.info}>
          <div className={styles.tag}>
            <div className={styles.tagLine}>"{content.tagLine}"</div>
            <TagWork TagWork={content.tagWork} info={content.info} />
          </div>
        </div>
      </div>
      <div className={styles.longAd}></div>
      <div className={styles.contentContainer}>
        <div className={styles.contentComment}>
          <p className={styles.content}>{content.content}</p>
          <CommentSection />
        </div>
        <div className={styles.side}>
          <div className={styles.shortAd}></div>
          <ShowThumbnails />
        </div>
      </div>
    </div>
    </>
  );
}
