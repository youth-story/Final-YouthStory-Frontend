import React from "react";
import styles from "./CommunityPostReader.module.css";
import Header from "../../components/CommunityPostReader/Header/Header";
import Content from "../../components/CommunityPostReader/Content/Content";

export default function CommunityPostReader({content}) {

    return (
        <div className={styles.container}>
            <Header coverPic={content.coverPic} title={content.title} date={content.date} category={content.category} />
            <Content coverPic={content.coverPic} author={content.author} profilePic={content.profilePic} content={content.content} achievements={content.achievements} />
        </div>
    );

}