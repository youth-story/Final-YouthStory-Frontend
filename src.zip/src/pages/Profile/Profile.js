import React, { useState } from "react";
import styles from "./Profile.module.css";
import Header from "../../components/Profile/Header/Header";
import Articles from "../../components/Profile/Articles/Articles";
import addIcon from "./addIcon.png";
import PostModal from "../../components/Profile/Articles/PostModal/PostModal";

export default function Profile({ details, articles }) {
  const [postModal, setPostModal] = useState(false);

  const openPostModal = () => {
    setPostModal(true);
  };

  const closePostModal = () => {
    setPostModal(false);
  };

  return (
    <div className={styles.container}>
      <button className={styles.editProfile}>Edit Profile</button>
      <Header details={details} />
      <br />
      <br />
      <div className={styles.content}>
        <Articles articles={articles} />
        <img onClick={openPostModal} className={styles.addIcon} src={addIcon} alt="Add Icon" />
      </div>
      <PostModal
        isOpen={postModal}
        closeModal={closePostModal}
      />
    </div>
  );
}
