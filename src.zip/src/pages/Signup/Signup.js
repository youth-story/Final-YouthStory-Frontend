import React, {useState} from "react";
import Modal from "@material-ui/core/Modal";
import styles from "./Signup.module.css";
import SignupForm from '../../components/Signup/SignupForm/SignupForm';
 
export default function Signup({ open, handleOpen }) {
 
    return (
        <div className={styles.container} style={{filter: open ? "blur(4px)" : null}} >
            <button type="button" onClick={handleOpen}>
                Signup
            </button>
            <Modal
                open={open}
                className={styles.modalContainer}
            >
                <>
                <p className={styles.heading}>Sign Up to Continue</p>
                <p className={styles.website}>YouthStory.in</p> 
                <br />
                <SignupForm />
                </>
            </Modal>
        </div>
    );
}