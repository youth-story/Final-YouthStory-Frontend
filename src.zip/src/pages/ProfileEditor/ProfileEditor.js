import React, { useState } from "react";
import styles from "./ProfileEditor.module.css";
import InfoFields from "../../components/ProfileEditor/InfoFields/InfoFields";
import Banner from "../../components/ProfileEditor/Banner/Banner";
import TextEditor from "../../components/ProfileEditor/TextEditor/TextEditor";
import Image from "../../components/ProfileEditor/Image/Image";

export default function ProfileEditor() {

    const [data, setData] = useState({
        firstName: "",
        lastName: "",
        userName: "",
        oldPassword: "",
        newPassword: "",
        email: "",
        otp: "",
        banner: "",
        bio: "",
        image: ""
    });

    const updateData = (newData) => {
        setData((prevData) => ({...prevData, ...newData}));
    };

    const submitForm = () => {
        alert("Edited");
    }

  return (
    <div className={styles.container}>
      <form>
        <InfoFields data={data} updateData={updateData} />
        <Banner banner={data.banner} onChange={(e) => updateData({ banner: e })} />
        <div className={styles.bioImg}>
            <TextEditor bio={data.bio} onChange={updateData} />
            <Image imageData={data.image} onChange={(e) => updateData({ image: e })} />
        </div>
        <div className={styles.saveBtnContainer}>
            <button onClick={submitForm} className={styles.saveBtn}>Save</button>
        </div>
      </form>
    </div>
  );
}
