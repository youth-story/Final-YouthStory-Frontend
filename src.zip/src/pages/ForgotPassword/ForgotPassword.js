import React, {useState} from "react";
import Modal from "@material-ui/core/Modal";
import styles from "./ForgotPassword.module.css";
import ForgotPasswordForm from '../../components/ForgotPassword/ForgotPasswordForm/ForgotPasswordForm';
 
export default function ForgotPassword({ open, handleOpen }) {
 
    return (
        <div className={styles.container} style={{filter: open ? "blur(4px)" : null}} >
            <button type="button" onClick={handleOpen}>
                Forgot Password
            </button>
            <Modal
                open={open}
                className={styles.modalContainer}
            >
                <>
                <h1 style={{fontSize: '2.5rem'}}>{'NO WORRIES:)'}</h1>
                <p className={styles.website}>YouthStory.in</p> 
                <ForgotPasswordForm />
                </>
            </Modal>
        </div>
    );
}