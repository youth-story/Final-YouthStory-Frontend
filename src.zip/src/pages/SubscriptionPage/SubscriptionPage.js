import React from "react";
import styles from "./SubscriptionPage.module.css";
import PlanOptions from "../../components/SubscriptionPage/PlanOptions/PlanOptions";
import CustomerReviews from "../../components/SubscriptionPage/CustomerReviews/CustomerReviews";

import planOptions from "../../constantsAPI/SubscriptionPage/planOptions"; // Replace this with API

export default function SubscriptionPage() {
  return (
    <div className={styles.container}>
      <p className={styles.heading}>Upgrade to D2D Premium</p>
      <div className={styles.planOptions}>
        {planOptions.map((plan, index) => (
            <PlanOptions key={index} plan={plan} />
        ))}
      </div>
      <CustomerReviews />
      <div className={styles.newsLetterPromo}>
        <p className={styles.newsLetterHeading}>Enjoy reading newsletters</p>
        <p className={styles.newsLetterPara}>Read valuable, high-quality content based on your interest and expertise</p>
      </div>
    </div>
  );
}
