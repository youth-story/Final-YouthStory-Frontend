import React, {useState} from "react";
import Modal from "@material-ui/core/Modal";
import styles from "./Login.module.css";
import LoginForm from '../../components/Login/LoginForm/LoginForm';
 
export default function Login({ open, handleOpen }) {
 
    return (
        <div className={styles.container} style={{filter: open ? "blur(4px)" : null}} >
            <button type="button" onClick={handleOpen}>
                Login
            </button>
            <Modal
                open={open}
                className={styles.modalContainer}
            >
                <>
                <h1 style={{fontSize: '2.5rem'}}>Welcome Back!</h1>
                <p className={styles.website}>YouthStory.in</p> 
                <LoginForm />
                </>
            </Modal>
        </div>
    );
}