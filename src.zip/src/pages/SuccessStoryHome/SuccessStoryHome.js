import React, { useState } from "react";
import styles from "./SuccessStoryHome.module.css";
import MenuBar from "../../components/SuccessStoryHome/MenuBar/MenuBar";

export default function SuccessStoryHome() {
  const [articleName, setArticleName] = useState("");

  return (
    <div className={styles.container}>
      <img
        className={styles.img}
        src="https://images.ctfassets.net/hrltx12pl8hq/3Mz6t2p2yHYqZcIM0ic9E2/3b7037fe8871187415500fb9202608f7/Man-Stock-Photos.jpg"
        alt="D2D Success Story Home Thumbnail"
      />
      <div className={styles.overlay}>
        <input
          className={styles.articleName}
          type="text"
          value={articleName}
          onChange={(e) => setArticleName(e.target.value)}
          placeholder="Search"
        />
      </div>
      <div className={styles.menuBar}>
        <MenuBar />
      </div>
    </div>
  );
}
