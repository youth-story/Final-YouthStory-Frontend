import React from "react";
import styles from "./ProfileInput.module.css";

const ProfileInput = ({ placeholder, value, onChange, type }) => {
  return (
    <div className={styles.profileInput}>
      <label className={styles.label}>{placeholder}</label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        className={styles.input}
      />
    </div>
  );
};

export default ProfileInput;