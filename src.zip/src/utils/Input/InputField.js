import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons'; 

import styles from './InputField.module.css';

const InputField = ({ placeholder, data, updateData }) => {
  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const inputType =
    placeholder.toLowerCase() === 'password' ? (showPassword ? 'text' : 'password') : placeholder.toLowerCase();

  return (
    <div className={styles.inputFieldContainer}>
      <div className={styles.inputFieldWithIcon}>
        <div className={styles.inputFieldWrapper}>
          <input
            type={inputType}
            value={data}
            placeholder={placeholder}
            onChange={(e) => updateData(e.target.value)}
            className={styles.customInput}
          />
          {placeholder.toLowerCase() === 'password' && (
            <div className={styles.passwordToggle} onClick={togglePasswordVisibility}>
              {showPassword ? (
                <FontAwesomeIcon icon={faEyeSlash} />
              ) : (
                <FontAwesomeIcon icon={faEye} />
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default InputField;
