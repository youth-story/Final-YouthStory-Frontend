import React from 'react';

const TruncateText = (Lines, text) => {

    const lines = text.split(' ');
    let truncatedText = lines.slice(0, Lines).join(' ');

    if (lines.length > Lines) {
      truncatedText += ' ...';
    }

    return truncatedText;
  };

export default TruncateText;
